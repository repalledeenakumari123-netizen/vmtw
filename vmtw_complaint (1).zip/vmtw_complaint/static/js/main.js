/* ── Toast ──────────────────────────────────────────────── */
function showToast(msg, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✅', danger: '❌', warning: '⚠️', info: 'ℹ️' };
  const t = document.createElement('div');
  t.className = `vmtw-toast ${type}`;
  t.innerHTML = `<span style="font-size:1.1rem">${icons[type] || '📢'}</span><span>${msg}</span>`;
  container.appendChild(t);
  setTimeout(() => {
    t.style.opacity = '0'; t.style.transition = '.3s';
    setTimeout(() => t.remove(), 300);
  }, 3500);
}

/* ── OTP Page Logic ─────────────────────────────────────── */
const mobileInp      = document.getElementById('mobile-input');
const sendBtn        = document.getElementById('send-btn');
const otpCard        = document.getElementById('otp-card');
const otpDisplayCard = document.getElementById('otp-display-card');
const demoOtpVal     = document.getElementById('demo-otp-value');
const resendBtn      = document.getElementById('resend-btn');
const verifyBtn      = document.getElementById('verify-btn');
const otpBoxes       = document.querySelectorAll('.otp-box');
const otpTimerEl     = document.getElementById('otp-timer');
let timerInterval;

/* OTP box keyboard handling */
otpBoxes.forEach((box, i, arr) => {
  box.addEventListener('input', () => {
    box.value = box.value.replace(/\D/g, '').slice(0, 1);
    if (box.value) {
      box.classList.add('filled');
      if (i < arr.length - 1) arr[i + 1].focus();
    } else {
      box.classList.remove('filled');
    }
  });
  box.addEventListener('keydown', e => {
    if (e.key === 'Backspace' && !box.value && i > 0) arr[i - 1].focus();
  });
  box.addEventListener('paste', e => {
    e.preventDefault();
    const digits = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6).split('');
    digits.forEach((d, idx) => {
      if (arr[idx]) { arr[idx].value = d; arr[idx].classList.add('filled'); }
    });
    arr[Math.min(digits.length, arr.length - 1)].focus();
  });
});

function getOtpValue() {
  return Array.from(otpBoxes).map(b => b.value).join('');
}

function startTimer(seconds = 300) {
  if (timerInterval) clearInterval(timerInterval);
  let remaining = seconds;
  if (resendBtn) resendBtn.classList.add('hidden');

  function tick() {
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    if (otpTimerEl) otpTimerEl.textContent = `${m}:${s.toString().padStart(2, '0')}`;
    if (--remaining < 0) {
      clearInterval(timerInterval);
      if (otpTimerEl) otpTimerEl.textContent = 'Expired';
      if (resendBtn) resendBtn.classList.remove('hidden');
      if (demoOtpVal) demoOtpVal.textContent = '------';
    }
  }
  tick();
  timerInterval = setInterval(tick, 1000);
}

async function sendOtp(isResend = false) {
  const mobile = mobileInp ? mobileInp.value.trim() : '';
  if (!/^\d{10}$/.test(mobile)) {
    showToast('Please enter a valid 10-digit mobile number.', 'danger');
    return;
  }

  const btn  = isResend ? resendBtn : sendBtn;
  const orig = btn ? btn.innerHTML : '';
  if (btn) {
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending…';
    btn.disabled = true;
  }

  try {
    const fd = new FormData();
    fd.append('action', 'send_otp');
    fd.append('mobile', mobile);
    const res  = await fetch('/verify', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.success) {
      showToast(data.message, 'success');
      if (mobileInp) mobileInp.disabled = true;

      // Show OTP display card (demo mode)
      if (data.demo_otp && otpDisplayCard) {
        otpDisplayCard.classList.remove('hidden');
        if (demoOtpVal) demoOtpVal.textContent = data.demo_otp;
        const hint = document.getElementById('otp-hint');
        if (hint) hint.textContent = 'Copy the OTP from the yellow box above and enter here.';
      }

      if (otpCard) otpCard.classList.remove('hidden');
      startTimer(300);
      updateStepsSafe(2);
      otpBoxes[0] && otpBoxes[0].focus();
    } else {
      showToast(data.message, 'danger');
    }
  } catch (e) {
    showToast('Network error. Please try again.', 'danger');
  } finally {
    if (btn) { btn.innerHTML = orig; btn.disabled = false; }
  }
}

async function verifyOtp() {
  const otp = getOtpValue();
  if (otp.length < 6) { showToast('Please enter the complete 6-digit OTP.', 'danger'); return; }

  if (verifyBtn) {
    verifyBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Verifying…';
    verifyBtn.disabled = true;
  }

  try {
    const fd = new FormData();
    fd.append('action', 'verify_otp');
    fd.append('otp', otp);
    const res  = await fetch('/verify', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.success) {
      showToast('OTP verified! Redirecting…', 'success');
      clearInterval(timerInterval);
      updateStepsSafe(3);
      setTimeout(() => { window.location.href = data.redirect; }, 900);
    } else {
      showToast(data.message, 'danger');
      otpBoxes.forEach(b => { b.value = ''; b.classList.remove('filled'); });
      otpBoxes[0] && otpBoxes[0].focus();
      if (verifyBtn) { verifyBtn.innerHTML = '<i class="bi bi-unlock-fill me-2"></i>Verify OTP'; verifyBtn.disabled = false; }
    }
  } catch {
    showToast('Network error.', 'danger');
    if (verifyBtn) { verifyBtn.innerHTML = '<i class="bi bi-unlock-fill me-2"></i>Verify OTP'; verifyBtn.disabled = false; }
  }
}

function updateStepsSafe(step) {
  if (typeof updateSteps === 'function') updateSteps(step);
}

/* ── Upload Preview ─────────────────────────────────────── */
const fileInput   = document.getElementById('file-input');
const uploadPrev  = document.getElementById('upload-preview');
const uploadCont  = document.getElementById('upload-content');

if (fileInput) {
  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = e => {
        if (uploadPrev) { uploadPrev.src = e.target.result; uploadPrev.classList.remove('d-none'); }
        if (uploadCont) uploadCont.innerHTML = `<i class="bi bi-check-circle text-success fs-4"></i><div class="mt-1 small text-success fw-semibold">${file.name}</div>`;
      };
      reader.readAsDataURL(file);
    } else if (file) {
      if (uploadCont) uploadCont.innerHTML = `<i class="bi bi-file-earmark-check text-primary fs-4"></i><div class="mt-1 small text-primary fw-semibold">${file.name}</div>`;
    }
  });
}

/* ── Drag & Drop ────────────────────────────────────────── */
const uploadZone = document.getElementById('upload-zone');
if (uploadZone) {
  uploadZone.addEventListener('dragover', e => { e.preventDefault(); uploadZone.style.borderColor = '#3b82f6'; });
  uploadZone.addEventListener('dragleave', () => { uploadZone.style.borderColor = ''; });
  uploadZone.addEventListener('drop', e => {
    e.preventDefault(); uploadZone.style.borderColor = '';
    if (fileInput && e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      fileInput.dispatchEvent(new Event('change'));
    }
  });
}

/* ── Auto-fill track input from URL ─────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const trackInp = document.getElementById('track-input');
  if (id && trackInp) trackInp.value = id;

  // Enter key on mobile input triggers send
  if (mobileInp) {
    mobileInp.addEventListener('keypress', e => { if (e.key === 'Enter') sendOtp(); });
  }
});
