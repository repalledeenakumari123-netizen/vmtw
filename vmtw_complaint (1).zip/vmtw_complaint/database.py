import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'vmtw.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                mobile    TEXT    NOT NULL UNIQUE,
                verified  INTEGER DEFAULT 0,
                created_at TEXT   DEFAULT (datetime('now','localtime'))
            );

            CREATE TABLE IF NOT EXISTS otps (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                mobile     TEXT    NOT NULL,
                otp        TEXT    NOT NULL,
                created_at REAL    NOT NULL,
                verified   INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS complaints (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT    UNIQUE NOT NULL,
                mobile       TEXT    NOT NULL,
                name         TEXT    DEFAULT 'Anonymous',
                department   TEXT    NOT NULL,
                title        TEXT    NOT NULL,
                description  TEXT    NOT NULL,
                image_path   TEXT,
                status       TEXT    DEFAULT 'Received',
                submitted_at TEXT    DEFAULT (datetime('now','localtime')),
                updated_at   TEXT    DEFAULT (datetime('now','localtime'))
            );

            CREATE TABLE IF NOT EXISTS admin (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id   TEXT    UNIQUE NOT NULL,
                password   TEXT    NOT NULL,
                role       TEXT    DEFAULT 'Principal'
            );

            INSERT OR IGNORE INTO admin (admin_id, password, role)
            VALUES ('principal_vmtw', 'admin@123', 'Principal');
        ''')
    print("✅ Database initialised at", DB_PATH)

if __name__ == '__main__':
    init_db()
