# 🛡️ VMTW Anonymous Complaint Portal

**Vignan's Institute of Management and Technology for Women**
Anonymous Complaint System with Fake ID Detection

---

## 📁 Project Structure

```
vmtw_complaint/
├── app.py                 ← Main Flask application
├── database.py            ← Database setup & helpers
├── requirements.txt       ← Python dependencies
├── Procfile               ← Render/Heroku deployment
├── render.yaml            ← Render.com auto-deploy config
├── vmtw.db                ← SQLite database (auto-created)
├── templates/
│   ├── base.html          ← Shared layout with navbar
│   ├── index.html         ← Home page
│   ├── verify.html        ← OTP verification
│   ├── complaint_form.html← Complaint submission
│   ├── track.html         ← Complaint tracking
│   ├── admin_login.html   ← Admin login
│   ├── admin_panel.html   ← Admin dashboard
│   └── view_complaint.html← Complaint detail view
└── static/
    ├── css/style.css      ← All custom styles
    ├── js/main.js         ← All JavaScript
    ├── images/            ← Favicon, images
    └── uploads/           ← Uploaded evidence files
```

---

## 🚀 Run Locally

### Step 1 — Install Python 3.10+
Download from python.org. Tick "Add to PATH" during install.

### Step 2 — Open terminal in project folder
```bash
cd vmtw_complaint
```

### Step 3 — Create virtual environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 4 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 5 — Run
```bash
python app.py
```

Open browser → **http://127.0.0.1:5000**

---

## 🔑 Admin Login

| Field    | Value            |
|----------|------------------|
| Admin ID | `principal_vmtw` |
| Password | `admin@123`      |
| URL      | `/admin/login`   |

---

## 📱 Configure Twilio for Real SMS

1. Sign up at **twilio.com** (free trial)
2. Get: Account SID, Auth Token, Phone Number
3. Set environment variables or edit `app.py`:

```python
TWILIO_SID    = 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
TWILIO_TOKEN  = 'your_auth_token'
TWILIO_NUMBER = '+1XXXXXXXXXX'
COUNTRY_CODE  = '+91'
```

Install Twilio:
```bash
pip install twilio
```

Without Twilio → OTP shown on screen (Demo Mode).

---

## 🌐 Deploy on Render.com (Free Public URL)

### Step 1 — Push to GitHub
1. Create account at github.com
2. New repository → `vmtw-complaint-portal`
3. Upload all project files

### Step 2 — Deploy on Render
1. Go to **render.com** → Sign up with GitHub
2. New → Web Service → Connect your repository
3. Configure:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Environment:** Python 3
4. Add Environment Variables:
   - `SECRET_KEY` → (any random string)
   - `TWILIO_ACCOUNT_SID` → your SID
   - `TWILIO_AUTH_TOKEN` → your token
   - `TWILIO_PHONE_NUMBER` → your Twilio number
5. Click **Deploy**

After 2-3 minutes you get a URL like:
```
https://vmtw-complaint-portal.onrender.com
```

Share this link — anyone can access the website!

---

## 🔒 Departments Supported
CSE, CSE-AI, CSE-DS, IT, ECE, EEE, MBA, BBA

## 📊 Complaint Statuses
- **Received** — Complaint filed
- **In Review** — Under Principal's review  
- **Resolved** — Issue addressed
