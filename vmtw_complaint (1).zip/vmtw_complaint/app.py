import os, random, string, time
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify, flash, send_from_directory)
from werkzeug.utils import secure_filename

from database import get_db, init_db

# ─────────────────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'vmtw_secret_2024_change_in_prod')

UPLOAD_FOLDER   = os.path.join('static', 'uploads')
ALLOWED_EXT     = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'webp'}
MAX_UPLOAD_MB   = 16
app.config['UPLOAD_FOLDER']      = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_UPLOAD_MB * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ── Twilio config ─────────────────────────────────────────────────────────────
TWILIO_SID    = os.environ.get('TWILIO_ACCOUNT_SID',  'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
TWILIO_TOKEN  = os.environ.get('TWILIO_AUTH_TOKEN',   'your_auth_token_here')
TWILIO_NUMBER = os.environ.get('TWILIO_PHONE_NUMBER', '+1XXXXXXXXXX')
COUNTRY_CODE  = os.environ.get('COUNTRY_CODE',        '+91')

# ── Init DB on startup ────────────────────────────────────────────────────────
init_db()

# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def gen_complaint_id():
    return 'VMTW-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def gen_otp():
    return str(random.randint(100000, 999999))

def is_twilio_configured():
    return not (TWILIO_SID.startswith('ACxxx') or
                TWILIO_TOKEN == 'your_auth_token_here' or
                TWILIO_NUMBER == '+1XXXXXXXXXX')

def send_otp_sms(mobile, otp):
    """Send OTP via Twilio. Falls back to terminal print in demo mode."""
    if not is_twilio_configured():
        print(f"\n{'='*55}\n  [DEMO] OTP for {mobile}: {otp}\n{'='*55}\n")
        return True, 'demo'
    try:
        from twilio.rest import Client
        client = Client(TWILIO_SID, TWILIO_TOKEN)
        msg = client.messages.create(
            body=f"VMTW Complaint Portal OTP: {otp}\nValid for 5 minutes. Do not share.",
            from_=TWILIO_NUMBER,
            to=f"{COUNTRY_CODE}{mobile}"
        )
        print(f"✅ SMS sent | SID: {msg.sid}")
        return True, 'sms'
    except ImportError:
        print(f"\n❌ twilio not installed. Run: pip install twilio")
        print(f"   FALLBACK OTP for {mobile}: {otp}\n")
        return False, 'not_installed'
    except Exception as e:
        print(f"\n❌ Twilio error: {e}")
        print(f"   FALLBACK OTP for {mobile}: {otp}\n")
        return False, str(e)

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            flash('Please login to access admin panel.', 'warning')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated

# ─────────────────────────────────────────────────────────────────────────────
#  PUBLIC ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    with get_db() as db:
        total    = db.execute('SELECT COUNT(*) FROM complaints').fetchone()[0]
        resolved = db.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0]
    return render_template('index.html', total=total, resolved=resolved,
                           demo_mode=not is_twilio_configured())


# ── OTP Verification ──────────────────────────────────────────────────────────

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        action = request.form.get('action')
        mobile = request.form.get('mobile', '').strip()

        if action == 'send_otp':
            if not mobile or not mobile.isdigit() or len(mobile) < 10:
                return jsonify({'success': False,
                                'message': 'Please enter a valid 10-digit mobile number.'})
            # Rate limit: max 3 per hour
            with get_db() as db:
                cutoff = (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
                cnt = db.execute(
                    "SELECT COUNT(*) FROM complaints WHERE mobile=? AND submitted_at>?",
                    (mobile, cutoff)).fetchone()[0]
                if cnt >= 5:
                    return jsonify({'success': False,
                                    'message': 'Too many complaints from this number. Try later.'})

            otp = gen_otp()
            ok, mode = send_otp_sms(mobile, otp)

            with get_db() as db:
                db.execute('DELETE FROM otps WHERE mobile=?', (mobile,))
                db.execute('INSERT INTO otps (mobile, otp, created_at) VALUES (?,?,?)',
                           (mobile, otp, time.time()))
                db.execute('INSERT OR IGNORE INTO users (mobile) VALUES (?)', (mobile,))

            session['pending_mobile'] = mobile

            if mode == 'sms':
                msg = f'OTP sent to +91{mobile}. Check your SMS!'
            elif mode == 'demo':
                msg = 'Demo Mode: OTP shown on screen. Check the highlighted box.'
            else:
                msg = f'SMS failed ({mode}). OTP shown on screen as fallback.'

            # In demo mode return OTP in response so UI can show it
            resp = {'success': True, 'message': msg, 'mode': mode}
            if mode != 'sms':
                resp['demo_otp'] = otp
            return jsonify(resp)

        elif action == 'verify_otp':
            entered        = request.form.get('otp', '').strip()
            pending_mobile = session.get('pending_mobile')

            if not pending_mobile:
                return jsonify({'success': False, 'message': 'Session expired. Please start again.'})

            with get_db() as db:
                rec = db.execute(
                    'SELECT * FROM otps WHERE mobile=? AND verified=0 ORDER BY id DESC LIMIT 1',
                    (pending_mobile,)).fetchone()

                if not rec:
                    return jsonify({'success': False, 'message': 'OTP not found. Request a new one.'})
                if time.time() - rec['created_at'] > 300:
                    return jsonify({'success': False, 'message': 'OTP expired. Request a new one.'})
                if rec['otp'] != entered:
                    return jsonify({'success': False, 'message': 'Incorrect OTP. Try again.'})

                db.execute('UPDATE otps SET verified=1 WHERE id=?', (rec['id'],))
                db.execute('UPDATE users SET verified=1 WHERE mobile=?', (pending_mobile,))

            session['verified_mobile'] = pending_mobile
            session['otp_verified']    = True
            return jsonify({'success': True, 'redirect': url_for('complaint_form')})

    return render_template('verify.html', demo_mode=not is_twilio_configured())


# ── Complaint Submission ──────────────────────────────────────────────────────

@app.route('/complaint', methods=['GET', 'POST'])
def complaint_form():
    if not session.get('otp_verified'):
        flash('Please verify your mobile number first.', 'warning')
        return redirect(url_for('verify'))

    if request.method == 'POST':
        name        = request.form.get('name', '').strip() or 'Anonymous'
        department  = request.form.get('department', '').strip()
        title       = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        mobile      = session.get('verified_mobile', 'unknown')

        if not all([department, title, description]):
            flash('Please fill all required fields.', 'danger')
            return render_template('complaint_form.html')

        image_path = None
        if 'image' in request.files:
            f = request.files['image']
            if f and f.filename and allowed_file(f.filename):
                fname      = secure_filename(f.filename)
                uname      = f"{int(time.time())}_{fname}"
                f.save(os.path.join(app.config['UPLOAD_FOLDER'], uname))
                image_path = uname

        cid = gen_complaint_id()
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        with get_db() as db:
            db.execute(
                '''INSERT INTO complaints
                   (complaint_id,mobile,name,department,title,description,image_path,submitted_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?)''',
                (cid, mobile, name, department, title, description, image_path, now, now))

        session.pop('otp_verified',    None)
        session.pop('verified_mobile', None)
        session.pop('pending_mobile',  None)

        return render_template('complaint_form.html', success=True, complaint_id=cid)

    return render_template('complaint_form.html')


# ── Track Complaint ───────────────────────────────────────────────────────────

@app.route('/track', methods=['GET', 'POST'])
def track():
    complaint = None
    error     = None
    cid_val   = request.args.get('id', '')

    if request.method == 'POST':
        cid_val = request.form.get('complaint_id', '').strip().upper()

    if cid_val:
        with get_db() as db:
            complaint = db.execute(
                'SELECT * FROM complaints WHERE complaint_id=?', (cid_val,)).fetchone()
        if not complaint:
            error = f'No complaint found with ID: {cid_val}'

    return render_template('track.html', complaint=complaint, error=error, cid_val=cid_val)


# ─────────────────────────────────────────────────────────────────────────────
#  ADMIN ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_panel'))

    error = None
    if request.method == 'POST':
        admin_id = request.form.get('admin_id', '').strip()
        password = request.form.get('password', '').strip()

        with get_db() as db:
            row = db.execute(
                'SELECT * FROM admin WHERE admin_id=? AND password=?',
                (admin_id, password)).fetchone()

        if row:
            session['admin_logged_in'] = True
            session['admin_id']        = admin_id
            session['admin_role']      = row['role']
            flash(f'Welcome, {row["role"]}!', 'success')
            return redirect(url_for('admin_panel'))
        error = 'Invalid Admin ID or Password.'

    return render_template('admin_login.html', error=error)


@app.route('/admin/logout')
def admin_logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('admin_login'))


@app.route('/admin')
@admin_required
def admin_panel():
    sf = request.args.get('status', '')
    df = request.args.get('dept', '')
    search = request.args.get('search', '').strip()

    q = 'SELECT * FROM complaints WHERE 1=1'
    p = []
    if sf:     q += ' AND status=?';     p.append(sf)
    if df:     q += ' AND department=?'; p.append(df)
    if search: q += ' AND (title LIKE ? OR complaint_id LIKE ?)'; p += [f'%{search}%', f'%{search}%']
    q += ' ORDER BY submitted_at DESC'

    with get_db() as db:
        complaints  = db.execute(q, p).fetchall()
        stats = {
            'total':    db.execute('SELECT COUNT(*) FROM complaints').fetchone()[0],
            'received': db.execute("SELECT COUNT(*) FROM complaints WHERE status='Received'").fetchone()[0],
            'review':   db.execute("SELECT COUNT(*) FROM complaints WHERE status='In Review'").fetchone()[0],
            'resolved': db.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0],
        }
        depts = db.execute('SELECT DISTINCT department FROM complaints ORDER BY department').fetchall()

    return render_template('admin_panel.html',
                           complaints=complaints, stats=stats, depts=depts,
                           status_filter=sf, dept_filter=df, search=search)


@app.route('/admin/update_status', methods=['POST'])
@admin_required
def update_status():
    cid    = request.form.get('complaint_id')
    status = request.form.get('status')
    valid  = ['Received', 'In Review', 'Resolved']
    if status not in valid:
        return jsonify({'success': False, 'message': 'Invalid status'})
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with get_db() as db:
        db.execute('UPDATE complaints SET status=?, updated_at=? WHERE complaint_id=?',
                   (status, now, cid))
    return jsonify({'success': True, 'message': f'Status updated to "{status}"'})


@app.route('/admin/delete/<cid>', methods=['POST'])
@admin_required
def delete_complaint(cid):
    with get_db() as db:
        row = db.execute('SELECT image_path FROM complaints WHERE complaint_id=?', (cid,)).fetchone()
        if row and row['image_path']:
            fp = os.path.join(app.config['UPLOAD_FOLDER'], row['image_path'])
            if os.path.exists(fp):
                os.remove(fp)
        db.execute('DELETE FROM complaints WHERE complaint_id=?', (cid,))
    return jsonify({'success': True, 'message': 'Complaint deleted.'})


@app.route('/admin/view_image/<filename>')
@admin_required
def view_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/admin/complaint/<cid>')
@admin_required
def view_complaint(cid):
    with get_db() as db:
        c = db.execute('SELECT * FROM complaints WHERE complaint_id=?', (cid,)).fetchone()
    if not c:
        flash('Complaint not found.', 'danger')
        return redirect(url_for('admin_panel'))
    return render_template('view_complaint.html', c=c)


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("\n" + "="*60)
    print("  VMTW Anonymous Complaint Portal")
    print("  URL   : http://127.0.0.1:5000")
    print("  Admin : http://127.0.0.1:5000/admin/login")
    print("  Login : principal_vmtw / admin@123")
    mode = "LIVE SMS via Twilio" if is_twilio_configured() else "DEMO (OTP shown on screen)"
    print(f"  OTP   : {mode}")
    print("="*60 + "\n")
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
